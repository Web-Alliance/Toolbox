<?php

/**
 * ajoute mon menu au panneau d'admin de WP
 *
 * @return void
 */
function CWA_addAdminLink(){
    add_menu_page('Clean DB après l\'import', // Titre de la page
    'Clean-WA-AfterImport', // Texte de l'onglet du menu
    'manage_options', // capacité de l'utilisateur à voir le menu selon son rôle
    __DIR__.'/CWA-menu.php','', 'dashicons-database' ); // ressource à appeler à l'affichage de la page;
}
    

function CWA_clean_dbimport_route(){
    register_rest_route('AFI/v1', '/CWA_cleanDB', [
        'methods' => 'GET', 
        'callback' => function(){
            return CWA_clean_dbimport();
        },
    ]);
}


function CWA_clean_dbimport(){
    global $wpdb;
    $request = "SELECT ID, guid  FROM `".$wpdb->prefix."posts` WHERE `guid` like '%456.web-alliance.biz%'";
    $data= $wpdb->get_results(
        $wpdb->prepare($request)
    );
    $count = 0;
    // foreach($data as $article){
    //     $correction =  isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) ? 'https://' : 'http://' . $_SERVER['HTTP_HOST']. end(explode("/", $article->guid));
    //     $wpdb->update( $wpdb->prefix . 'posts', ['guid'=> $correction], [ 'id' => $article->ID ]);
    //     $count++;
    // }
    // $correction = $count;
    $correction = $_SERVER['HTTP_HOST'];


    return json_encode($correction);
}