<?php
wp_enqueue_style('CWA-css-admin', trailingslashit(PLUG_DIR_CWA) . 'assets/css/CWA-admin.css', false, '1.0', 'all');
?>


<div class="wrap">
    <h1>Nettoyer la bdd après un import d'articles</h1>
    <div class='CWA-Container'>
        <h2>Cliquez sur le bouton pour nettoyer la bdd</h2>
        <button id="cleanBtn">Nettoyer maintenant</button>
        <div class="loaderContainer">
            
        </div>
    </div>
</div>

<script src="<?= trailingslashit(PLUG_DIR_CWA) . 'assets/js/CWA-admin.js' ?>" type="module" id="CWA-admin-js"></script>