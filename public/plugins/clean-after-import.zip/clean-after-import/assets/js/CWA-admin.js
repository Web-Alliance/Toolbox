(() => {
  let cleanBtn = document.getElementById("cleanBtn");
  cleanBtn.addEventListener("click", async () => {
   let response = await cleanDB();
   if(response){
    let container = document.querySelector('.loaderContainer')
    console.log(response)
    container.innerHTML = `<p>c\'est finit la famille</p>
    <p>${response} correction${response != 0 && response > 1  ? 's' : ""} apporté${response != 0 && response > 1  ? 'es' : ""}</p>`
   } else {
    container.innerHTML = 'ça s\'est mal passé la famille'
   }
  });
})();

async function cleanDB() {
  displayloader()
  let response = await fetch("/wp-json/AFI/v1/CWA_cleanDB", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });
  try {
    let data = await response.json();
    displayloader(false)
    return data;
  }
  catch (error){
    console.error(error);
    displayloader(false)

    return false
  }
}

function displayloader(display = true){
    let container = document.querySelector('.loaderContainer')
    if(display){
        container.innerHTML = `
        <div class="load">
        <hr/><hr/><hr/><hr/>
      </div>`
    } else {
        container.innerHTML = ''
    }
}