<?php

/**
    Plugin Name: Clean-afterImport
    Description:  
    Author: Vaugoyeau Jérémy
    Author URI:       https://github.com/VjeremyV
    Version: 0.9
 */

 define('PLUG_DIR_CWA', plugin_dir_url(__FILE__));
require_once plugin_dir_path(__FILE__) . 'functions/CWA-functions.php';
add_action('rest_api_init', 'CWA_clean_dbimport_route');
add_action( 'admin_menu', 'CWA_addAdminLink' );


